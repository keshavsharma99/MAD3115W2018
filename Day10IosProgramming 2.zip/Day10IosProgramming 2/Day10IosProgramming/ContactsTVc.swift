

import UIKit
import Contacts

struct myContacts {
    var givenName:String
    var familyName:String
    var phoneNo:String
    var emailId:String
    
}
class ContactsTVc: UITableViewController {

    @IBOutlet weak var contactsTable: UITableView!
    var myContactStore = CNContactStore()
    var myContactslist = [myContacts]()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = 70
        contactsTable.reloadData()
        contactsTable.delegate = self
        contactsTable.dataSource = self
        myContactStore.requestAccess(for: .contacts) { (success, error) in
            if success  {
                print("Authorization Succesfull")
            }
        }
    self.fetchContacts()
    }
    func fetchContacts()
    {
        let Key = [CNContactGivenNameKey,CNContactFamilyNameKey,CNContactPhoneNumbersKey,CNContactEmailAddressesKey] as [CNKeyDescriptor]
        
        
        let request = CNContactFetchRequest(keysToFetch: Key)
        try!myContactStore.enumerateContacts(with: request) {
            (contact, stoppingPointer)
         in
        print("Contact: \(contact)")
        
            let givenName = contact.givenName as String
            let familyName = contact.familyName as String
            var phoneNo = " "
            if (contact.phoneNumbers.isEmpty) {
                phoneNo = contact.phoneNumbers[0].value
                .stringValue
            }
            
            var emailId = ""
            if(!contact.emailAddresses.isEmpty) {
                emailId = contact.emailAddresses[0].value as String
            }
            
            self.myContactslist.append(myContacts(givenName: givenName, familyName: familyName, phoneNo: phoneNo, emailId: emailId))
            self.contactsTable.reloadData()
            
}
    }
 

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return myContactslist.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomisedCell
        
        cell.title.text = "\(myContactslist[indexPath.row].givenName) \(myContactslist[indexPath.row].familyName)"
        cell.subtitle.text = "\(myContactslist[indexPath.row].phoneNo)"
        print(cell.subtitle.text = "\(myContactslist[indexPath.row].phoneNo)")
        return cell
        }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        performSegue(withIdentifier: "to_main", sender: nil)
        
        
    }


}
