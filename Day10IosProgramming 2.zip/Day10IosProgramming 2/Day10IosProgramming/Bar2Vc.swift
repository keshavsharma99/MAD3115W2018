
import UIKit
import CallKit
import MessageUI
class Bar2Vc: UIViewController {


    @IBOutlet weak var Call_Out: UIButton!
    @IBOutlet weak var Text_Outlet: UIButton!

    @IBAction func Call_Action(_ sender: Any) {
        print("Calling....")
        let url = URL(string: "tel://+11231231231")
        
        if UIApplication.shared.canOpenURL(url!){
            
            if #available(iOS 10,*)
            {
                UIApplication.shared.open(url!)
            }
            else {
                UIApplication.shared.openURL(url!)
                
            }
            
            }
}
    
    @IBAction func Text_Action(_ sender: Any) {
        
        
        
        print("Messaging")
        
        if
        
            MFMessageComposeViewController.canSendText() {
            let messagevc = MFMessageComposeViewController()
            messagevc.body = "Hello, how are you?"
            messagevc.recipients = ["+11231231231"]
            messagevc.messageComposeDelegate = self as? MFMessageComposeViewControllerDelegate
            self.present(messagevc, animated: true, completion: nil)
            
            }
    }
    
    @IBAction func Email_Action(_ sender: Any) {
    print("sending email")
        
        
        if MFMailComposeViewController.canSendMail() {
            let emailPicker = MFMailComposeViewController()
            
            
            emailPicker.mailComposeDelegate = self as? MFMailComposeViewControllerDelegate
            emailPicker.setSubject("Test Email")
            emailPicker.setMessageBody("Hello, how are you", isHTML: true)
            self.present(emailPicker, animated: true, completion: nil)
        }
    }
    
    @IBOutlet weak var EmailText: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }



}
